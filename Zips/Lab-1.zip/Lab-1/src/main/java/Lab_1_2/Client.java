package Lab_1_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	 public static void main(String[] args) {

		 ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");

		 Employee d = context.getBean(Employee.class);

		// SBU s = context.getBean(SBU.class);
		 
		 System.out.println("Employee Details \n");

		 System.out.println("---------------------------------------------- \n");

		 System.out.println(d.toString());
		

		 }
}
