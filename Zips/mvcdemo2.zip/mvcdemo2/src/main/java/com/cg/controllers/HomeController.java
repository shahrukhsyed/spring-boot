package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Trainee;
import com.cg.services.TraineeService;

@Controller
@RequestMapping("/")
public class HomeController {

	@Autowired private TraineeService service;
	/*public ModelAndView methodName(){}
	 public String methodName(Model model){}
	 public String methoedName(map<String,object> model){}*/
	@GetMapping
	public String home(Model model) {
		model.addAttribute("msg","Welcome to Spring webmvc");
		return "home";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String search(Model model,@RequestParam("user")String user,@RequestParam("password")String pass) {
		if(user=="admin"&&pass=="admin123")
		model.addAttribute("msg","Trainee Management System");
		return "operations";
	}
	/*adding................................................................................*/
	@RequestMapping(value="/addtrainee",method=RequestMethod.GET)
	public String add(Model model) {
		model.addAttribute("msg","Add Trainee");
		return "addtrainee";
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String addtrainee(Model model,@ModelAttribute("trainee") Trainee trainee) {
		model.addAttribute("msg","Add Trainee");
		
		service.create(trainee);
		
		return "addtrainee";
	}
	//....................................................................................
	
	//Delete Trainee........................................
	@RequestMapping(value="/deletetrainee",method=RequestMethod.GET)
	public String delete(Model model) {
		model.addAttribute("msg"," Delete Trainee");
		return "deletetrainee";
	}
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String deleteById(Model model,@RequestParam("deleteId") int id) {
		model.addAttribute("list",this.service.find(id));
		return "deletetrainee";
	}
	@RequestMapping(value="/deletetrainee/{id}",method=RequestMethod.POST)
	public String delete(Model model,@PathVariable("id") int id) {
		model.addAttribute("msg","Add Trainee");
		service.delete(id);
		return "deletetrainee";
	}
	
	//..........................................................
	
	//modiefy trainee..........................................
	@RequestMapping(value="/modiefytrainee",method=RequestMethod.GET)
	public String modiefy(Model model) {
		model.addAttribute("msg"," modiefy Trainee");
		return "modiefytrainee";
	}
	@RequestMapping(value="/modiefy",method=RequestMethod.POST)
	public String modiefyByid(Model model,@RequestParam("modiefyId") int id) {
		model.addAttribute("list",this.service.find(id));
		return "modiefytrainee";
	}
	@RequestMapping(value="/modiefytrainee",method=RequestMethod.POST)
	public String modiefy(Model model,@ModelAttribute("trainee") Trainee trainee) {
		model.addAttribute("msg","Add Trainee");
		service.modify(trainee);
		return "modiefytrainee";
	}
	//..........................................................
	
	
	//retrieve trainee by id............................
	@RequestMapping(value="/retrievetrainee",method=RequestMethod.GET)
	public String retrieve(Model model) {
		model.addAttribute("msg","Retrieve Trainee");
		return "retrievetrainee";
	}
	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public String retrievebyid(Model model,@RequestParam("retrieveId") int id ) {
		
		model.addAttribute("list",this.service.find(id));
		
		return "retrievetrainee";
	}
	//........................................................
	
	//for retrieveing all trainee..................
	@RequestMapping(value="/retrievealltreainee",method=RequestMethod.GET)
	public String retrieveall(Model model) {
		
		model.addAttribute("list", this.service.getAll());
		
		return "retrievealltreainee";
	}
	//.........................................................
}
