# spring5-july-19
Spring 5 At CG 

## List of Demos and Walkthroughs

 Description | Source Code | Walkthrough
-------------|-------------|------------
 Spring MVC Steps 1||[Walkthrough](spring-mvc-steps1.md)
 Spring MVC Steps 2||[Walkthrough](spring-mvc-steps2.md)
 Spring MVC Steps 3||[Walkthrough](spring-mvc-steps3.md)
 Spring Web MVC Project without Spring boot |  | 
 Spring Web MVC With Spring boot | [Project](./demo-sources/mvc-boot/) | [Walkthrough](spring-boot-project.md)
 Spring REST Demo1 | [Project](./demo-sources/rest-demo1) | [Walkthrough](rest-demo1.md)
 Spring Boot Data-JPA | [Project](./demo-sources/data-jpa-demo) |[Walkthrough](spring-boot-data-jpa-demo.md)
 