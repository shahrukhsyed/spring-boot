package com.cg.services;

import java.util.List;


import com.cg.entities.Trainee;

public interface TraineeService {
	  Trainee find(int traineeId);
	    List<Trainee> getAll();
	    void create(Trainee p);
	    public void delete(int traineeId);
	    public void modify(Trainee p);
}
