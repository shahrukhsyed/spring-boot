package com.cg.controllers;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Message;

@RestController
@RequestMapping("/test")
public class HomeController {
	
	@GetMapping(value="/",produces= {"application/json","application/xml"} )
	public Message testGet() {
		return new Message("This is Get request");
	}
	@PostMapping(value="/",produces= {"application/json","application/xml"} )
	public Message testPost() {
		return new Message("This is Post request");
	}
	@PutMapping(value="/",produces= {"application/json","application/xml"} )
	public Message testPut() {
		return new Message("This is Put request");
	}
	@DeleteMapping(value="/",produces= {"application/json","application/xml"} )
	public Message testDelete() {
		return new Message("This is Delete request");
	}
	
}
