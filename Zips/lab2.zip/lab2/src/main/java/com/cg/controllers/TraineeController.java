package com.cg.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class TraineeController {
	
	/* Request Handling Method
	 * syntax:
	 * 1. public ModelAndView methodName(){}
	 * 2. public String methodName(Model model){}
	 * 3. public String methodName(Map<String,Object> madel){}
	 * 4. public String methodName(){}
	 */
	@GetMapping
	public String home(Model model){
		model.addAttribute("msg","Trainee Details");
		return "login";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String loggedIn(Model model,@RequestParam("user")String user,@RequestParam("pwd")String pass){
		if(user.equals("admin")&&pass.equals("admin123"))				
		return "operation";
		else
			return "login";
	}
	@RequestMapping(value="/addTrainee",method=RequestMethod.GET)
	public String add(){

			return "addTrainee";
	}
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String delete(){

			return "delete";
	}
	
	@RequestMapping(value="/modify",method=RequestMethod.GET)
	public String modify(){

			return "modify";
	}
	@RequestMapping(value="/retrieve",method=RequestMethod.GET)
	public String retrieve(){

			return "retrieve";
	}
	
}
