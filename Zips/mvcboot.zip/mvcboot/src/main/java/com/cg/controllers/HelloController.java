package com.cg.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;

@RestController //Rest Controller returns Model and NOT 
public class HelloController {
	
	@GetMapping("/") //Home page
	public String hello() {
		return "Hello Shahrukh!!!";
	}
	
	//URL=https://localhost:3000/
	@GetMapping("/products")
	public List<Product> getProducts(){
		List<Product> list=new LinkedList<Product>();
		 list.add(new Product(101,"Windows","64Bit OS for Desktop & Laptop",8000.00));
		 list.add(new Product(102,"Linux","32Bit OS for Desktop & Laptop",5000.00));
		 list.add(new Product(103,"Unix","64Bit OS for Desktop & Laptop",7000.00));
		return list;
	}
}
