package com.cg.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;

@Repository
public class TraineeDAOImpl implements TraineeDAO {

    @PersistenceContext
    private EntityManager em;
    
    
    public void save(Trainee p) {
        em.persist(p);
        em.flush();
    }

   
    public Trainee findById(Integer traineeId) {
        return em.find(Trainee.class, traineeId);
    }

   
    public List<Trainee> findAll() {
        Query q = em.createQuery("from Trainee p");//That's "JPQL" not SQL !!!
        return q.getResultList();
       // List<Trainee> traineeList =em.createQuery("from Trainee p").getResultList();
		
		//return traineeList;
    }


	@Override
	public void delete(Integer traineeId) {
		// TODO Auto-generated method stub
		Trainee tr= em.find(Trainee.class, traineeId);
		em.remove(tr);
		
		
	}


	@Override
	public void modify(Trainee p) {
		// TODO Auto-generated method stub
//		Trainee tr=em.find(Trainee.class, traineeId);
//		tr.setTraineeId(p.getTraineeId());
//		tr.setTraineeName(p.getTraineeName());
//		tr.setTraineeLocation(p.getTraineeLocation());
//		tr.setTraineeDomain(p.getTraineeDomain());
		em.merge(p);
	}
}