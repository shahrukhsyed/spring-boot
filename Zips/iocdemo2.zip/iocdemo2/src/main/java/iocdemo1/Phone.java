package iocdemo1;

public class Phone {

}
