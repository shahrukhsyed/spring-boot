export class Country {
     code:string;
	 name:string;
	 continent:string;
     capital:string;
}
